# Exercise: Front End Assessment
Create a HTML and CSS one page website using [core_guide.jpg](https://github.com/moringaschool/preCourseWork/blob/master/psd2html/pce1/core_guide.jpg) as a guide to how it will look like finally.

##### Important:

 1. You may use a font of your liking.
 2. Do not change the layout or image sizes.


All the best...
